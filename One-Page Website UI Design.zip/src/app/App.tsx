import { useState, useEffect } from "react"
import {
  Menu, X, ArrowRight, Check, Mail, MessageCircle,
  Clock, Shield, Zap, Globe, Code2, Layout,
  Star, ChevronRight, Phone, ExternalLink, Users,
} from "lucide-react"
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback"
import logoImg from "@/imports/Geometric__B__Logo_with_Circuit-Style_Wordmark_20260617_131813_0000-2.png"

// ─── Constants ───────────────────────────────────────────────────────────────
const WA_NUM = "916367207775"
const EMAIL = "maliv7511@gmail.com"
const PHONE = "+91 6367207775"
function waLink(msg = "") {
  return `https://wa.me/${WA_NUM}${msg ? `?text=${encodeURIComponent(msg)}` : ""}`
}

// ─── Types ────────────────────────────────────────────────────────────────────
type PlanItem = { label: string; price: number }
type Plan = {
  name: string
  price: number | "custom"
  tagline: string
  popular?: boolean
  features: string[]
  items: PlanItem[]
}

// ─── Pricing Data ─────────────────────────────────────────────────────────────
const PLANS: Record<string, Plan[]> = {
  Portfolio: [
    {
      name: "Starter",
      price: 8999,
      tagline: "Get online fast",
      features: ["5 custom pages", "Mobile responsive", "Contact form", "Basic SEO", "1 revision round", "Deployment guide"],
      items: [
        { label: "Custom UI Design", price: 2500 },
        { label: "5-Page Development", price: 3000 },
        { label: "Contact Form", price: 1000 },
        { label: "Basic SEO Setup", price: 999 },
        { label: "Mobile Optimization", price: 500 },
        { label: "Deployment & Handoff", price: 0 },
      ],
    },
    {
      name: "Professional",
      price: 15999,
      tagline: "For serious creatives",
      popular: true,
      features: ["8 custom pages", "Scroll animations", "Full SEO + sitemap", "CMS integration", "3 revision rounds", "30-day support"],
      items: [
        { label: "Premium Design System", price: 4000 },
        { label: "8-Page Development", price: 5000 },
        { label: "Scroll Animations", price: 2000 },
        { label: "Full SEO + XML Sitemap", price: 2499 },
        { label: "CMS Integration", price: 1500 },
        { label: "30-Day Post-Launch Support", price: 1000 },
      ],
    },
    {
      name: "Premium",
      price: 27999,
      tagline: "Maximum impact",
      features: ["Unlimited pages", "Design system", "Advanced animations", "E-commerce ready", "Analytics setup", "6-month support"],
      items: [
        { label: "Full Design System", price: 7000 },
        { label: "Unlimited Page Development", price: 8000 },
        { label: "Advanced Animations", price: 4000 },
        { label: "E-Commerce Integration", price: 5000 },
        { label: "Analytics + Advanced SEO", price: 2499 },
        { label: "6-Month Priority Support", price: 1500 },
      ],
    },
  ],
  Business: [
    {
      name: "Basic",
      price: 12999,
      tagline: "Establish your presence",
      features: ["6 pages", "Google Maps embed", "WhatsApp button", "Mobile responsive", "Basic SEO", "Contact form"],
      items: [
        { label: "Business UI Design", price: 3500 },
        { label: "6-Page Development", price: 4000 },
        { label: "Google Maps + WhatsApp", price: 1500 },
        { label: "Basic SEO Setup", price: 1999 },
        { label: "Contact Form + Lead Capture", price: 1000 },
        { label: "Deployment", price: 1000 },
      ],
    },
    {
      name: "Standard",
      price: 22999,
      tagline: "Grow your business",
      popular: true,
      features: ["10 pages", "Blog/news section", "Full SEO", "Payment integration", "CMS", "3 revision rounds"],
      items: [
        { label: "Premium Business Design", price: 5500 },
        { label: "10-Page Development", price: 7000 },
        { label: "Blog + CMS Integration", price: 3000 },
        { label: "Payment Gateway Setup", price: 3000 },
        { label: "Full SEO + Analytics", price: 2499 },
        { label: "2-Month Post-Launch Support", price: 2000 },
      ],
    },
    {
      name: "Enterprise",
      price: 40000,
      tagline: "Full digital transformation",
      features: ["Custom pages", "Admin dashboard", "Multi-language", "Advanced SEO", "E-commerce", "Priority support"],
      items: [
        { label: "Enterprise Design System", price: 10000 },
        { label: "Custom Development", price: 15000 },
        { label: "Admin Dashboard", price: 6000 },
        { label: "Multi-language Support", price: 4000 },
        { label: "E-Commerce + Payments", price: 3000 },
        { label: "6-Month Priority Support", price: 2000 },
      ],
    },
  ],
  "Web Apps": [
    {
      name: "MVP",
      price: 29999,
      tagline: "Validate your idea fast",
      features: ["Core feature set", "User auth", "Basic CRUD", "Responsive UI", "API integration", "1-month support"],
      items: [
        { label: "UI/UX Design", price: 6000 },
        { label: "Frontend Development", price: 10000 },
        { label: "Backend + Database", price: 8000 },
        { label: "User Authentication", price: 2999 },
        { label: "API Integration", price: 2000 },
        { label: "Deployment + 1-Month Support", price: 1000 },
      ],
    },
    {
      name: "Standard",
      price: 54999,
      tagline: "Production-ready app",
      popular: true,
      features: ["Full feature set", "Auth + roles", "Admin dashboard", "Email notifications", "3rd-party APIs", "3-month support"],
      items: [
        { label: "Full UI/UX Design System", price: 12000 },
        { label: "Frontend Development", price: 18000 },
        { label: "Backend + REST API", price: 14000 },
        { label: "Auth + Role Management", price: 4999 },
        { label: "Email + Notification System", price: 3000 },
        { label: "3-Month Support & Updates", price: 3000 },
      ],
    },
    {
      name: "Custom",
      price: "custom",
      tagline: "Complex, scalable apps",
      features: ["Fully custom scope", "Microservices arch", "Real-time features", "Scalable infra", "Full QA", "Ongoing retainer"],
      items: [
        { label: "Discovery & Architecture", price: 0 },
        { label: "Custom Development", price: 0 },
        { label: "Infrastructure Setup", price: 0 },
        { label: "Testing & QA", price: 0 },
        { label: "Launch + Monitoring", price: 0 },
        { label: "Ongoing Retainer (monthly)", price: 0 },
      ],
    },
  ],
}

// ─── Portfolio Data ───────────────────────────────────────────────────────────
const PORTFOLIO = [
  {
    title: "Aryan Mehta — Photographer",
    category: "Portfolio",
    img: "https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=600&h=400&fit=crop&auto=format",
    desc: "Minimal, high-contrast portfolio with full-bleed galleries",
  },
  {
    title: "Spice & Ember Restaurant",
    category: "Business",
    img: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=600&h=400&fit=crop&auto=format",
    desc: "Reservation system, menu management, and location pages",
  },
  {
    title: "TaskFlow — PM Dashboard",
    category: "Web App",
    img: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop&auto=format",
    desc: "Kanban-style project management with team collaboration",
  },
  {
    title: "Ravi Sharma — Architect",
    category: "Portfolio",
    img: "https://images.unsplash.com/photo-1487958449943-2429e8be8625?w=600&h=400&fit=crop&auto=format",
    desc: "Clean grid-based portfolio for an architecture firm",
  },
  {
    title: "PrimeCare Clinic",
    category: "Business",
    img: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=600&h=400&fit=crop&auto=format",
    desc: "Appointment booking, service pages, and staff directory",
  },
  {
    title: "FinScope — Analytics",
    category: "Web App",
    img: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=600&h=400&fit=crop&auto=format",
    desc: "Real-time financial tracking dashboard with charts",
  },
]

// ─── Navbar ───────────────────────────────────────────────────────────────────
const NAV_LINKS = [
  { label: "About", href: "#about" },
  { label: "Process", href: "#process" },
  { label: "Portfolio", href: "#portfolio" },
  { label: "Pricing", href: "#pricing" },
  { label: "Contact", href: "#contact" },
]

function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 24)
    window.addEventListener("scroll", fn)
    return () => window.removeEventListener("scroll", fn)
  }, [])

  return (
    <nav
      className="fixed top-0 w-full z-50 transition-all duration-300"
      style={{
        background: scrolled ? "rgba(13,22,36,0.95)" : "transparent",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        borderBottom: scrolled ? "1px solid rgba(0,207,238,0.1)" : "1px solid transparent",
        boxShadow: scrolled ? "0 4px 24px rgba(0,0,0,0.3)" : "none",
      }}
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <a href="#" className="flex items-center gap-3 flex-shrink-0">
          <div className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0" style={{ border: "1.5px solid rgba(0,207,238,0.35)" }}>
            <ImageWithFallback src={logoImg} alt="ByteBuild logo" className="w-full h-full object-cover" />
          </div>
          <span className="font-bold text-lg tracking-wide text-[#EEF4FF]">ByteBuild</span>
        </a>

        <div className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map(l => (
            <a key={l.href} href={l.href} className="text-sm text-[#7A9BB8] hover:text-[#EEF4FF] transition-colors duration-200">
              {l.label}
            </a>
          ))}
        </div>

        <div className="hidden md:block">
          <a
            href="#contact"
            className="px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200"
            style={{ background: "#00CFEE", color: "#0D1624" }}
            onMouseEnter={e => (e.currentTarget.style.background = "#00E5FF")}
            onMouseLeave={e => (e.currentTarget.style.background = "#00CFEE")}
          >
            Get a Quote
          </a>
        </div>

        <button
          className="md:hidden text-[#EEF4FF] p-2 rounded-lg"
          onClick={() => setOpen(v => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {open && (
        <div
          className="md:hidden px-6 py-4 flex flex-col gap-3"
          style={{ background: "rgba(13,22,36,0.98)", borderTop: "1px solid rgba(0,207,238,0.1)" }}
        >
          {NAV_LINKS.map(l => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm text-[#7A9BB8] hover:text-[#EEF4FF] py-1.5 transition-colors"
              onClick={() => setOpen(false)}
            >
              {l.label}
            </a>
          ))}
          <a
            href="#contact"
            className="mt-1 px-4 py-2.5 rounded-lg text-sm font-semibold text-center"
            style={{ background: "#00CFEE", color: "#0D1624" }}
            onClick={() => setOpen(false)}
          >
            Get a Quote
          </a>
        </div>
      )}
    </nav>
  )
}

// ─── Hero ─────────────────────────────────────────────────────────────────────
const STATS = [
  { value: "30+", label: "Projects Delivered" },
  { value: "25+", label: "Happy Clients" },
  { value: "98%", label: "On-Time Delivery" },
  { value: "5★", label: "Client Rating" },
]

function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-16 overflow-hidden">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse 80% 55% at 50% -5%, rgba(0,207,238,0.09) 0%, transparent 65%)" }}
      />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: "linear-gradient(rgba(0,207,238,1) 1px, transparent 1px), linear-gradient(90deg, rgba(0,207,238,1) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
          opacity: 0.025,
        }}
      />

      <div className="relative max-w-7xl mx-auto px-6 py-24 text-center w-full">
        <div
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm mb-8"
          style={{ border: "1px solid rgba(0,207,238,0.25)", background: "rgba(0,207,238,0.06)", color: "#00CFEE" }}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[#00CFEE] animate-pulse" />
          Freelance Web Development Studio · Based in India
        </div>

        <h1 className="text-5xl md:text-7xl font-extrabold text-[#EEF4FF] leading-[1.05] tracking-tight mb-6 max-w-4xl mx-auto">
          Websites That{" "}
          <span style={{ color: "#00CFEE" }}>Work</span>{" "}
          As Hard As You Do
        </h1>

        <p className="text-lg md:text-xl text-[#7A9BB8] max-w-2xl mx-auto mb-10 leading-relaxed">
          Portfolios, business sites, and web apps — built with precision,
          delivered on time, designed to convert.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <a
            href="#portfolio"
            className="px-8 py-3.5 rounded-xl font-semibold text-base flex items-center gap-2 group transition-all duration-200"
            style={{ background: "#00CFEE", color: "#0D1624" }}
            onMouseEnter={e => (e.currentTarget.style.background = "#00E5FF")}
            onMouseLeave={e => (e.currentTarget.style.background = "#00CFEE")}
          >
            View My Work
            <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </a>
          <a
            href="#contact"
            className="px-8 py-3.5 rounded-xl font-semibold text-base text-[#EEF4FF] transition-all duration-200"
            style={{ border: "1px solid rgba(0,207,238,0.3)" }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = "rgba(0,207,238,0.6)"; e.currentTarget.style.background = "rgba(0,207,238,0.05)" }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(0,207,238,0.3)"; e.currentTarget.style.background = "transparent" }}
          >
            Get a Quote
          </a>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-10 md:gap-16">
          {STATS.map(s => (
            <div key={s.label} className="flex flex-col items-center gap-1">
              <span className="text-3xl md:text-4xl font-extrabold text-[#EEF4FF]">{s.value}</span>
              <span className="text-xs text-[#7A9BB8] tracking-wide">{s.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── About ────────────────────────────────────────────────────────────────────
const TRUST = [
  { icon: Zap, title: "Fast Delivery", desc: "Projects shipped in 7–21 days without cutting corners on quality." },
  { icon: Code2, title: "Clean Code", desc: "Maintainable, well-structured code any developer can pick up." },
  { icon: Layout, title: "Mobile-First", desc: "Every pixel tested across devices — from iPhone SE to 4K." },
  { icon: Shield, title: "Ongoing Support", desc: "Free 30-day bug fixes post-launch, with extended plans available." },
]

function About() {
  return (
    <section id="about" className="py-24" style={{ background: "#111D2E" }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <span className="text-xs font-semibold tracking-widest uppercase mb-4 block" style={{ color: "#00CFEE" }}>
              About ByteBuild
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-[#EEF4FF] mb-6 leading-tight">
              Precision-Built Websites for Ambitious People
            </h2>
            <p className="text-[#7A9BB8] leading-relaxed mb-5">
              I'm Maliv — a freelance web developer based in India. I build fast, accessible, and
              beautifully designed websites for creators, entrepreneurs, and growing businesses.
              Every project starts with a conversation, not a template.
            </p>
            <p className="text-[#7A9BB8] leading-relaxed mb-8">
              With 5+ years of hands-on experience, I've helped clients across industries establish
              their digital presence — from personal portfolios to full-stack web applications.
            </p>
            <a
              href={waLink("Hi ByteBuild! I'd like to discuss a project.")}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 font-semibold transition-all hover:gap-2.5"
              style={{ color: "#00CFEE" }}
            >
              Let's talk <ChevronRight className="w-4 h-4" />
            </a>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            {TRUST.map(({ icon: Icon, title, desc }) => (
              <div
                key={title}
                className="p-5 rounded-xl transition-all duration-200 group"
                style={{ background: "#0D1624", border: "1px solid rgba(0,207,238,0.1)" }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.28)")}
                onMouseLeave={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.1)")}
              >
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center mb-4"
                  style={{ background: "rgba(0,207,238,0.1)" }}
                >
                  <Icon className="w-5 h-5" style={{ color: "#00CFEE" }} />
                </div>
                <h3 className="font-semibold text-[#EEF4FF] mb-2">{title}</h3>
                <p className="text-sm text-[#7A9BB8] leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Process ──────────────────────────────────────────────────────────────────
const STEPS = [
  { n: "01", title: "Discover", desc: "A deep-dive call to understand your goals, audience, and success metrics. No guesswork.", icon: Users },
  { n: "02", title: "Design", desc: "Wireframes and high-fidelity mockups. You approve the look before any code is written.", icon: Layout },
  { n: "03", title: "Develop", desc: "Pixel-perfect implementation using modern tech — responsive, fast, accessible from day one.", icon: Code2 },
  { n: "04", title: "Deploy", desc: "Full handoff with documentation, domain setup, and a 30-day support window post-launch.", icon: Globe },
]

function Process() {
  return (
    <section id="process" className="py-24" style={{ background: "#0D1624" }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <span className="text-xs font-semibold tracking-widest uppercase mb-4 block" style={{ color: "#00CFEE" }}>
            How It Works
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-[#EEF4FF]">
            From Idea to Launch in 4 Steps
          </h2>
        </div>

        <div className="relative grid md:grid-cols-4 gap-8">
          <div
            className="hidden md:block absolute top-10 h-px pointer-events-none"
            style={{
              left: "calc(12.5% + 1.5rem)",
              right: "calc(12.5% + 1.5rem)",
              background: "linear-gradient(to right, transparent, rgba(0,207,238,0.3) 20%, rgba(0,207,238,0.3) 80%, transparent)",
            }}
          />

          {STEPS.map(({ n, title, desc, icon: Icon }) => (
            <div key={n} className="relative flex flex-col items-center text-center">
              <div
                className="relative w-20 h-20 rounded-full flex items-center justify-center mb-6 transition-all duration-200"
                style={{ background: "#111D2E", border: "1px solid rgba(0,207,238,0.2)" }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.5)")}
                onMouseLeave={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.2)")}
              >
                <Icon className="w-7 h-7" style={{ color: "#00CFEE" }} />
                <span
                  className="absolute -top-2.5 -right-2.5 w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center"
                  style={{ background: "#00CFEE", color: "#0D1624" }}
                >
                  {n.slice(-1)}
                </span>
              </div>
              <h3 className="font-bold text-[#EEF4FF] text-lg mb-3">{title}</h3>
              <p className="text-sm text-[#7A9BB8] leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Portfolio ────────────────────────────────────────────────────────────────
const CATS = ["All", "Portfolio", "Business", "Web App"]

function Portfolio() {
  const [active, setActive] = useState("All")
  const filtered = active === "All" ? PORTFOLIO : PORTFOLIO.filter(p => p.category === active)

  return (
    <section id="portfolio" className="py-24" style={{ background: "#111D2E" }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <span className="text-xs font-semibold tracking-widest uppercase mb-4 block" style={{ color: "#00CFEE" }}>
            My Work
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-[#EEF4FF] mb-4">Recent Projects</h2>
          <p className="text-[#7A9BB8] max-w-xl mx-auto">
            A curated selection across portfolios, business sites, and web apps.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {CATS.map(cat => (
            <button
              key={cat}
              onClick={() => setActive(cat)}
              className="px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-200"
              style={
                active === cat
                  ? { background: "#00CFEE", color: "#0D1624" }
                  : { border: "1px solid rgba(0,207,238,0.2)", color: "#7A9BB8" }
              }
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map(item => (
            <div
              key={item.title}
              className="group rounded-xl overflow-hidden transition-all duration-300 hover:-translate-y-1"
              style={{ background: "#0D1624", border: "1px solid rgba(0,207,238,0.1)" }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.3)")}
              onMouseLeave={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.1)")}
            >
              <div className="relative overflow-hidden aspect-video" style={{ background: "#162035" }}>
                <img
                  src={item.img}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 flex items-end p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300" style={{ background: "linear-gradient(to top, rgba(13,22,36,0.85), transparent)" }}>
                  <span className="text-white text-sm font-medium flex items-center gap-1.5">
                    View Project <ExternalLink className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
              <div className="p-5">
                <span
                  className="inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold mb-3"
                  style={{ background: "rgba(0,207,238,0.1)", color: "#00CFEE" }}
                >
                  {item.category}
                </span>
                <h3 className="font-semibold text-[#EEF4FF] mb-1.5">{item.title}</h3>
                <p className="text-sm text-[#7A9BB8]">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Pricing Modal ────────────────────────────────────────────────────────────
function PricingModal({ plan, tab, onClose }: { plan: Plan; tab: string; onClose: () => void }) {
  const total = plan.price === "custom" ? null : plan.price
  const advance = total ? Math.round(total * 0.5) : null

  const waMsg = total
    ? `Hi ByteBuild! I'm interested in the ${tab} — ${plan.name} plan (₹${total.toLocaleString("en-IN")}). I'd like to pay the 50% advance of ₹${advance!.toLocaleString("en-IN")} and get started!`
    : `Hi ByteBuild! I'm interested in a Custom Web App. Could you share pricing details?`

  useEffect(() => {
    document.body.style.overflow = "hidden"
    return () => { document.body.style.overflow = "" }
  }, [])

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0" style={{ background: "rgba(0,0,0,0.72)", backdropFilter: "blur(6px)" }} />
      <div
        className="relative w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl"
        style={{ background: "#111D2E", border: "1px solid rgba(0,207,238,0.22)", boxShadow: "0 32px 64px rgba(0,0,0,0.6)" }}
        onClick={e => e.stopPropagation()}
      >
        <div
          className="sticky top-0 px-6 py-4 flex items-center justify-between"
          style={{ background: "#111D2E", borderBottom: "1px solid rgba(0,207,238,0.1)" }}
        >
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest mb-0.5" style={{ color: "#00CFEE" }}>{tab}</p>
            <h3 className="font-bold text-[#EEF4FF] text-lg">{plan.name} Plan</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors"
            style={{ background: "#0D1624", border: "1px solid rgba(0,207,238,0.15)", color: "#7A9BB8" }}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-6 py-5">
          <p className="text-xs text-[#7A9BB8] uppercase tracking-widest mb-4">Itemized Breakdown</p>
          <div className="space-y-0 mb-5">
            {plan.items.map((item, i) => (
              <div
                key={i}
                className="flex items-center justify-between py-3"
                style={{ borderBottom: i < plan.items.length - 1 ? "1px solid rgba(0,207,238,0.07)" : "none" }}
              >
                <span className="text-sm text-[#C0D4E8]">{item.label}</span>
                <span className="text-sm font-medium" style={{ color: item.price === 0 ? "#00CFEE" : "#EEF4FF" }}>
                  {item.price === 0 ? "Included" : `₹${item.price.toLocaleString("en-IN")}`}
                </span>
              </div>
            ))}
          </div>

          {total ? (
            <div className="rounded-xl p-4 mb-5" style={{ background: "#0D1624", border: "1px solid rgba(0,207,238,0.15)" }}>
              <div className="flex justify-between items-center mb-3 pb-3" style={{ borderBottom: "1px solid rgba(0,207,238,0.1)" }}>
                <span className="text-sm text-[#7A9BB8]">Total</span>
                <span className="text-2xl font-extrabold text-[#EEF4FF]">₹{total.toLocaleString("en-IN")}</span>
              </div>
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-xs text-[#7A9BB8] mb-0.5">50% Advance to Begin</p>
                  <p className="text-xl font-bold" style={{ color: "#00CFEE" }}>₹{advance!.toLocaleString("en-IN")}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-[#7A9BB8] mb-0.5">Balance on Delivery</p>
                  <p className="font-semibold text-[#EEF4FF]">₹{advance!.toLocaleString("en-IN")}</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-xl p-4 mb-5 text-center" style={{ background: "#0D1624", border: "1px solid rgba(0,207,238,0.15)" }}>
              <p className="text-sm text-[#7A9BB8] mb-1">Custom pricing based on project scope</p>
              <p className="font-semibold" style={{ color: "#00CFEE" }}>Let's discuss your requirements</p>
            </div>
          )}

          <a
            href={waLink(waMsg)}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 rounded-xl text-white font-semibold flex items-center justify-center gap-2 transition-colors duration-200"
            style={{ background: "#25D366" }}
            onMouseEnter={e => (e.currentTarget.style.background = "#22C55E")}
            onMouseLeave={e => (e.currentTarget.style.background = "#25D366")}
          >
            <MessageCircle className="w-5 h-5" />
            {total ? `Book via WhatsApp — Pay ₹${advance!.toLocaleString("en-IN")} Advance` : "Discuss on WhatsApp"}
          </a>
        </div>
      </div>
    </div>
  )
}

// ─── Pricing ──────────────────────────────────────────────────────────────────
function Pricing() {
  const tabs = Object.keys(PLANS)
  const [activeTab, setActiveTab] = useState(tabs[0])
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null)

  return (
    <section id="pricing" className="py-24" style={{ background: "#0D1624" }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <span className="text-xs font-semibold tracking-widest uppercase mb-4 block" style={{ color: "#00CFEE" }}>
            Pricing
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-[#EEF4FF] mb-4">Transparent, Fixed Pricing</h2>
          <p className="text-[#7A9BB8] max-w-xl mx-auto">
            No hidden fees. No surprises. Pick a plan, see the full breakdown, and get started.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {tabs.map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className="px-5 py-2 rounded-xl text-sm font-semibold transition-all duration-200"
              style={
                activeTab === tab
                  ? { background: "#00CFEE", color: "#0D1624" }
                  : { border: "1px solid rgba(0,207,238,0.2)", color: "#7A9BB8" }
              }
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {PLANS[activeTab].map(plan => (
            <div
              key={plan.name}
              className="relative rounded-2xl p-6 flex flex-col transition-all duration-200 hover:-translate-y-1"
              style={{
                background: "#111D2E",
                border: plan.popular ? "1.5px solid rgba(0,207,238,0.5)" : "1px solid rgba(0,207,238,0.12)",
              }}
            >
              {plan.popular && (
                <span
                  className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap"
                  style={{ background: "#00CFEE", color: "#0D1624" }}
                >
                  Most Popular
                </span>
              )}

              <div className="mb-6">
                <h3 className="font-bold text-[#EEF4FF] text-xl mb-1">{plan.name}</h3>
                <p className="text-sm text-[#7A9BB8] mb-4">{plan.tagline}</p>
                {plan.price === "custom" ? (
                  <p className="text-3xl font-extrabold" style={{ color: "#00CFEE" }}>Custom</p>
                ) : (
                  <p className="text-3xl font-extrabold text-[#EEF4FF]">
                    ₹{plan.price.toLocaleString("en-IN")}
                    <span className="text-sm font-normal text-[#7A9BB8] ml-1">total</span>
                  </p>
                )}
              </div>

              <ul className="space-y-2.5 mb-8 flex-1">
                {plan.features.map(f => (
                  <li key={f} className="flex items-start gap-2.5 text-sm text-[#C0D4E8]">
                    <Check className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: "#00CFEE" }} />
                    {f}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => setSelectedPlan(plan)}
                className="w-full py-3 rounded-xl font-semibold text-sm transition-all duration-200"
                style={
                  plan.popular
                    ? { background: "#00CFEE", color: "#0D1624" }
                    : { border: "1px solid rgba(0,207,238,0.3)", color: "#00CFEE" }
                }
                onMouseEnter={e => {
                  if (plan.popular) e.currentTarget.style.background = "#00E5FF"
                  else e.currentTarget.style.background = "rgba(0,207,238,0.08)"
                }}
                onMouseLeave={e => {
                  if (plan.popular) e.currentTarget.style.background = "#00CFEE"
                  else e.currentTarget.style.background = "transparent"
                }}
              >
                {plan.price === "custom" ? "Let's Talk" : "View Details & Book"}
              </button>
            </div>
          ))}
        </div>
      </div>

      {selectedPlan && (
        <PricingModal plan={selectedPlan} tab={activeTab} onClose={() => setSelectedPlan(null)} />
      )}
    </section>
  )
}

// ─── Testimonials ─────────────────────────────────────────────────────────────
function Testimonials() {
  return (
    <section id="testimonials" className="py-24" style={{ background: "#111D2E" }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <span className="text-xs font-semibold tracking-widest uppercase mb-4 block" style={{ color: "#00CFEE" }}>
            Testimonials
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-[#EEF4FF] mb-4">What Clients Say</h2>
        </div>

        <div className="flex flex-col items-center text-center max-w-lg mx-auto">
          <div
            className="w-20 h-20 rounded-full flex items-center justify-center mb-6"
            style={{ background: "#0D1624", border: "1px solid rgba(0,207,238,0.2)" }}
          >
            <Star className="w-8 h-8" style={{ color: "rgba(0,207,238,0.35)" }} />
          </div>

          <div className="flex gap-1.5 mb-5">
            {[1, 2, 3, 4, 5].map(i => (
              <Star key={i} className="w-6 h-6" style={{ color: "rgba(0,207,238,0.22)", fill: "rgba(0,207,238,0.08)" }} />
            ))}
          </div>

          <h3 className="font-bold text-[#EEF4FF] text-xl mb-3">Be the First to Review</h3>
          <p className="text-[#7A9BB8] mb-8 leading-relaxed">
            I'm actively building my portfolio and would love your honest feedback. Work with me
            and share your experience — it means the world to a growing studio.
          </p>

          <div className="w-full grid sm:grid-cols-2 gap-4 mb-8 pointer-events-none select-none" style={{ opacity: 0.35 }}>
            {[0, 1].map(i => (
              <div
                key={i}
                className="p-5 rounded-xl text-left"
                style={{ background: "#0D1624", border: "1px solid rgba(0,207,238,0.1)" }}
              >
                <div className="flex gap-1 mb-3">
                  {[0, 1, 2, 3, 4].map(j => (
                    <div key={j} className="w-4 h-4 rounded-sm" style={{ background: "rgba(0,207,238,0.2)" }} />
                  ))}
                </div>
                <div className="space-y-2 mb-4">
                  <div className="h-3 rounded-full" style={{ background: "rgba(0,207,238,0.1)", width: "100%" }} />
                  <div className="h-3 rounded-full" style={{ background: "rgba(0,207,238,0.1)", width: "80%" }} />
                  <div className="h-3 rounded-full" style={{ background: "rgba(0,207,238,0.1)", width: "60%" }} />
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full" style={{ background: "rgba(0,207,238,0.1)" }} />
                  <div className="space-y-1">
                    <div className="h-2.5 rounded-full" style={{ background: "rgba(0,207,238,0.1)", width: "80px" }} />
                    <div className="h-2 rounded-full" style={{ background: "rgba(0,207,238,0.08)", width: "56px" }} />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <a
            href={waLink("Hi ByteBuild! I'd like to work with you.")}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-white font-semibold transition-colors duration-200"
            style={{ background: "#25D366" }}
            onMouseEnter={e => (e.currentTarget.style.background = "#22C55E")}
            onMouseLeave={e => (e.currentTarget.style.background = "#25D366")}
          >
            <MessageCircle className="w-4 h-4" />
            Become a Client & Reviewer
          </a>
        </div>
      </div>
    </section>
  )
}

// ─── Contact ──────────────────────────────────────────────────────────────────
type FormState = { name: string; email: string; type: string; budget: string; message: string }

function Contact() {
  const [form, setForm] = useState<FormState>({ name: "", email: "", type: "", budget: "", message: "" })
  const [sent, setSent] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const subject = `[ByteBuild] Inquiry from ${form.name}`
    const body = `Name: ${form.name}\nEmail: ${form.email}\nProject Type: ${form.type}\nBudget: ${form.budget}\n\nMessage:\n${form.message}`
    window.open(`mailto:${EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`)
    setSent(true)
  }

  const inputStyle = {
    background: "#0D1624",
    border: "1px solid rgba(0,207,238,0.15)",
    color: "#EEF4FF",
    outline: "none",
  }

  return (
    <section id="contact" className="py-24 relative overflow-hidden" style={{ background: "#0D1624" }}>
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse 60% 50% at 100% 100%, rgba(0,207,238,0.055) 0%, transparent 60%)" }}
      />
      <div className="relative max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-start">
          <div>
            <span className="text-xs font-semibold tracking-widest uppercase mb-4 block" style={{ color: "#00CFEE" }}>
              Get In Touch
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-[#EEF4FF] mb-6 leading-tight">
              Let's Build Something Great Together
            </h2>
            <p className="text-[#7A9BB8] leading-relaxed mb-8">
              Have a project in mind? Fill out the form and I'll respond within 24 hours.
              Or reach out directly via email or WhatsApp.
            </p>

            <div className="space-y-4 mb-8">
              {[
                { icon: Mail, label: "Email", value: EMAIL, href: `mailto:${EMAIL}` },
                { icon: Phone, label: "WhatsApp", value: PHONE, href: waLink() },
              ].map(({ icon: Icon, label, value, href }) => (
                <a
                  key={label}
                  href={href}
                  target={label === "WhatsApp" ? "_blank" : undefined}
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 group transition-colors"
                >
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center transition-all duration-200"
                    style={{ background: "#111D2E", border: "1px solid rgba(0,207,238,0.15)" }}
                  >
                    <Icon className="w-4 h-4" style={{ color: "#00CFEE" }} />
                  </div>
                  <div>
                    <p className="text-xs text-[#7A9BB8] mb-0.5">{label}</p>
                    <p className="text-sm text-[#EEF4FF]">{value}</p>
                  </div>
                </a>
              ))}
            </div>

            <a
              href={waLink("Hi ByteBuild! I'd like to discuss a new project.")}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-white font-semibold transition-colors duration-200"
              style={{ background: "#25D366" }}
              onMouseEnter={e => (e.currentTarget.style.background = "#22C55E")}
              onMouseLeave={e => (e.currentTarget.style.background = "#25D366")}
            >
              <MessageCircle className="w-5 h-5" />
              Chat on WhatsApp
            </a>
          </div>

          <div className="rounded-2xl p-6 md:p-8" style={{ background: "#111D2E", border: "1px solid rgba(0,207,238,0.12)" }}>
            {sent ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center mb-4"
                  style={{ background: "rgba(0,207,238,0.1)", border: "1px solid rgba(0,207,238,0.3)" }}
                >
                  <Check className="w-7 h-7" style={{ color: "#00CFEE" }} />
                </div>
                <h3 className="font-bold text-[#EEF4FF] text-xl mb-2">Message Sent!</h3>
                <p className="text-sm text-[#7A9BB8] mb-6">
                  Your email client opened with the pre-filled message. I'll respond within 24 hours.
                </p>
                <button
                  onClick={() => setSent(false)}
                  className="text-sm hover:underline transition-colors"
                  style={{ color: "#00CFEE" }}
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-[#7A9BB8] mb-1.5">Your Name</label>
                    <input
                      required
                      type="text"
                      placeholder="Arjun Sharma"
                      value={form.name}
                      onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                      className="w-full px-4 py-2.5 rounded-lg text-sm transition-colors duration-200"
                      style={inputStyle}
                      onFocus={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.5)")}
                      onBlur={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.15)")}
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#7A9BB8] mb-1.5">Email Address</label>
                    <input
                      required
                      type="email"
                      placeholder="arjun@email.com"
                      value={form.email}
                      onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                      className="w-full px-4 py-2.5 rounded-lg text-sm transition-colors duration-200"
                      style={inputStyle}
                      onFocus={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.5)")}
                      onBlur={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.15)")}
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-[#7A9BB8] mb-1.5">Project Type</label>
                    <select
                      required
                      value={form.type}
                      onChange={e => setForm(f => ({ ...f, type: e.target.value }))}
                      className="w-full px-4 py-2.5 rounded-lg text-sm transition-colors duration-200 appearance-none cursor-pointer"
                      style={inputStyle}
                      onFocus={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.5)")}
                      onBlur={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.15)")}
                    >
                      <option value="" disabled>Select type</option>
                      <option>Portfolio</option>
                      <option>Business Website</option>
                      <option>Web App</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-[#7A9BB8] mb-1.5">Budget Range</label>
                    <select
                      value={form.budget}
                      onChange={e => setForm(f => ({ ...f, budget: e.target.value }))}
                      className="w-full px-4 py-2.5 rounded-lg text-sm transition-colors duration-200 appearance-none cursor-pointer"
                      style={inputStyle}
                      onFocus={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.5)")}
                      onBlur={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.15)")}
                    >
                      <option value="">Select budget</option>
                      <option>Under ₹10,000</option>
                      <option>₹10,000 – ₹25,000</option>
                      <option>₹25,000 – ₹50,000</option>
                      <option>₹50,000+</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-[#7A9BB8] mb-1.5">Your Message</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Tell me about your project — goals, timeline, any specific requirements..."
                    value={form.message}
                    onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                    className="w-full px-4 py-2.5 rounded-lg text-sm transition-colors duration-200 resize-none"
                    style={inputStyle}
                    onFocus={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.5)")}
                    onBlur={e => (e.currentTarget.style.borderColor = "rgba(0,207,238,0.15)")}
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 transition-colors duration-200"
                  style={{ background: "#00CFEE", color: "#0D1624" }}
                  onMouseEnter={e => (e.currentTarget.style.background = "#00E5FF")}
                  onMouseLeave={e => (e.currentTarget.style.background = "#00CFEE")}
                >
                  <Mail className="w-4 h-4" />
                  Send Message
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="py-12" style={{ background: "#070E18", borderTop: "1px solid rgba(0,207,238,0.1)" }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-8 mb-10">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0" style={{ border: "1.5px solid rgba(0,207,238,0.35)" }}>
                <ImageWithFallback src={logoImg} alt="ByteBuild" className="w-full h-full object-cover" />
              </div>
              <span className="font-bold text-lg text-[#EEF4FF]">ByteBuild</span>
            </div>
            <p className="text-sm text-[#7A9BB8] leading-relaxed mb-5 max-w-xs">
              Freelance web development studio specializing in portfolios, business sites, and web apps. Based in India, serving worldwide.
            </p>
            <div className="flex flex-col gap-2.5">
              <a href={`mailto:${EMAIL}`} className="flex items-center gap-2 text-sm text-[#7A9BB8] transition-colors hover:text-[#00CFEE]">
                <Mail className="w-3.5 h-3.5" style={{ color: "#00CFEE" }} /> {EMAIL}
              </a>
              <a href={waLink()} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-[#7A9BB8] transition-colors hover:text-[#00CFEE]">
                <Phone className="w-3.5 h-3.5" style={{ color: "#00CFEE" }} /> {PHONE}
              </a>
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-widest mb-4" style={{ color: "#00CFEE" }}>Quick Links</p>
            <ul className="space-y-2.5">
              {["About", "Process", "Portfolio", "Pricing", "Contact"].map(link => (
                <li key={link}>
                  <a href={`#${link.toLowerCase()}`} className="text-sm text-[#7A9BB8] hover:text-[#EEF4FF] transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-widest mb-4" style={{ color: "#00CFEE" }}>Services</p>
            <ul className="space-y-2.5">
              {["Portfolio Websites", "Business Websites", "Web Applications", "SEO Optimization", "UI/UX Design"].map(s => (
                <li key={s} className="text-sm text-[#7A9BB8]">{s}</li>
              ))}
            </ul>
          </div>
        </div>

        <div
          className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#3A5272]"
          style={{ borderTop: "1px solid rgba(0,207,238,0.08)" }}
        >
          <p>© {new Date().getFullYear()} ByteBuild. All rights reserved.</p>
          <p>Crafted with precision by ByteBuild</p>
        </div>
      </div>
    </footer>
  )
}

// ─── WhatsApp FAB ─────────────────────────────────────────────────────────────
function WhatsAppFAB() {
  return (
    <a
      href={waLink("Hi ByteBuild! I'd like to discuss a project.")}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110"
      style={{ background: "#25D366", boxShadow: "0 8px 24px rgba(37,211,102,0.35)" }}
      onMouseEnter={e => (e.currentTarget.style.background = "#22C55E")}
      onMouseLeave={e => (e.currentTarget.style.background = "#25D366")}
    >
      <MessageCircle className="w-6 h-6 text-white" />
    </a>
  )
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Process />
        <Portfolio />
        <Pricing />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
      <WhatsAppFAB />
    </div>
  )
}
